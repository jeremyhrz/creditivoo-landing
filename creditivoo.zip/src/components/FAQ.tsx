/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { ChevronDown, Plus, Minus, HelpCircle } from 'lucide-react';

export default function FAQ() {
  const faqs = [
    {
      q: '¿Creditivoo es un banco?',
      a: 'No. Creditivoo no es una entidad bancaria. Es un sistema de financiamiento privado exclusivo para compras dentro del ecosistema IVOO.',
    },
    {
      q: '¿Necesito tarjeta de crédito?',
      a: 'No necesariamente. Las condiciones dependerán de tu proceso de evaluación digital y de los métodos de pago que decidas habilitar.',
    },
    {
      q: '¿Cuánto crédito me pueden aprobar?',
      a: 'El monto dependerá de tu perfil crediticio estimado, evaluación de ingresos y, principalmente, tu comportamiento de pago dentro de Creditivoo.',
    },
    {
      q: '¿Puedo pagar anticipado?',
      a: 'Sí, las condiciones lo permiten por completo. Pagar a tiempo o de forma anticipada es de hecho la mejor vía para acumular IVOOPoints rápido y aumentar tu línea.',
    },
    {
      q: '¿Qué pasa si pago tarde?',
      a: 'El retraso en el cumplimiento de tus pagos puede afectar directamente tus beneficios exclusivos, disminuir tu línea disponible y desmejorar tu perfil histórico dentro de Creditivoo.',
    },
    {
      q: '¿Qué son los IVOOPoints?',
      a: 'Son puntos asociados a tu comportamiento e historial de pagos dentro de Creditivoo. Sirven de indicador principal para desbloquear condiciones preferenciales (tales como inicial de 0%).',
    },
    {
      q: '¿Puedo usar Creditivoo con promociones?',
      a: 'Aplica según cada caso. Dependerá de las condiciones comerciales preestablecidas para la promoción, producto seleccionado o campaña específica activa.',
    },
    {
      q: '¿Dónde puedo pagar mis cuotas?',
      a: 'Los canales de pago oficiales disponibles (como transferencias, pago móvil u otros) serán informados con precisión durante tu solicitud y en el portal exclusivo del cliente.',
    },
    {
      q: '¿Qué productos puedo comprar?',
      a: 'Creditivoo aplica para un amplio y selecto catálogo de tecnología de punta, teléfonos inteligentes, televisores, línea blanca, informática y aires acondicionados disponibles en IVOO.',
    },
    {
      q: '¿Qué pasa si no me aprueban?',
      a: '¡No te preocupes! Podrás revisar los datos ingresados en tu solicitud, mejorar tu historial general e intentar nuevamente una postulación transcurrido el tiempo sugerido.',
    },
  ];

  // Store open state index for accordions (allows toggling Multiple)
  const [openIndexes, setOpenIndexes] = useState<number[]>([]);

  const toggleAccordion = (idx: number) => {
    if (openIndexes.includes(idx)) {
      setOpenIndexes(openIndexes.filter((i) => i !== idx));
    } else {
      setOpenIndexes([...openIndexes, idx]);
    }
  };

  return (
    <section id="preguntas" className="py-24 bg-white relative overflow-hidden font-sans">
      
      {/* Glow highlight */}
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono font-extrabold tracking-[0.25em] text-[#00E37C] uppercase bg-[#00E37C]/5 px-3.5 py-1.5 rounded-full border border-[#00E37C]/15">
            CENTRO DE AYUDA FAQ
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black text-slate-900 tracking-tight mt-5">
            Preguntas Frecuentes
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-[#00E37C] to-[#00FF88] mx-auto my-6 rounded-full" />
          <p className="text-slate-600 text-lg">
            ¿Tienes dudas sobre el sistema? Aquí recopilamos respuestas claras y oportunas.
          </p>
        </div>

        {/* Accordions Stack */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIndexes.includes(idx);
            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all duration-300 ${
                  isOpen
                    ? 'bg-[#00E37C]/5 border-[#00E37C]/30 shadow-sm'
                    : 'bg-slate-50 border border-slate-200/80 hover:border-slate-300'
                }`}
              >
                {/* Trigger Button */}
                <button
                  onClick={() => toggleAccordion(idx)}
                  className="w-full text-left px-6 py-5 flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                  id={`faq-btn-${idx}`}
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className={`w-5 h-5 shrink-0 ${isOpen ? 'text-[#00AA5B]' : 'text-slate-400'}`} />
                    <span className="font-display text-sm sm:text-base font-bold text-slate-800 tracking-tight">
                      {faq.q}
                    </span>
                  </div>
                  <div className={`w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 transition-all duration-300 ${isOpen ? 'rotate-180 text-[#00AA5B] bg-[#00E37C]/15' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {/* Animated Body */}
                <div
                  className={`grid transition-all duration-300 ease-in-out overflow-hidden ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0 pointer-events-none'
                  }`}
                >
                  <div className="overflow-hidden">
                    <div className="px-6 pb-6 pt-1 text-slate-600 text-xs sm:text-sm leading-relaxed border-t border-slate-200/50 mt-1">
                      {faq.a}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
