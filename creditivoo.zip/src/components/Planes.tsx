/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Check, ShieldCheck, Sparkles, HelpCircle } from 'lucide-react';

export default function Planes() {
  const handleScrollToForm = () => {
    const element = document.querySelector('#solicitud');
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const basicBenefits = [
    'Línea de crédito según evaluación.',
    'Inicial flexible.',
    'Pago en 3 cuotas.',
    'Acumulación de IVOOPoints.',
    'Acceso a productos seleccionados.',
    'Sin costo de membresía.',
  ];

  const plusBenefits = [
    'Mayor flexibilidad según tu perfil.',
    'Posibilidad de inicial de 0%.',
    'Aumento progresivo de línea de crédito.',
    'Multiplicador de IVOOPoints.',
    'Cashback o descuentos promocionales.',
    'Días de pago más flexibles.',
    'Beneficios en servicio técnico, instalación o reparación.',
    'Premios o beneficios especiales.',
  ];

  return (
    <section id="planes" className="py-24 bg-white relative overflow-hidden font-sans">
      {/* Background lights */}
      <div className="absolute top-1/2 left-0 w-96 h-96 rounded-full bg-[#00E37C]/5 blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-indigo-500/5 blur-[140px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono font-extrabold tracking-[0.25em] text-[#00E37C] uppercase bg-[#00E37C]/5 px-3.5 py-1.5 rounded-full border border-[#00E37C]/15">
            CONTRATACIONES
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black text-slate-900 tracking-tight mt-5">
            Planes Creditivoo
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-[#00E37C] to-[#00FF88] mx-auto my-6 rounded-full" />
          <p className="text-slate-600 text-lg">
            Elige el plan ideal según tus necesidades y empieza a construir tu mejor perfil crediticio.
          </p>
        </div>

        {/* Pricing Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 max-w-4xl mx-auto items-stretch">
          
          {/* PLAN BÁSICO */}
          <div className="rounded-3xl bg-slate-50 border border-slate-200 p-8 flex flex-col justify-between hover:border-slate-300 transition-all duration-300">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="font-display text-2xl font-bold text-slate-900 tracking-tight">
                    Plan Básico
                  </h3>
                  <p className="text-sm text-slate-500 mt-1">
                    Para empezar fácil.
                  </p>
                </div>
                <span className="text-[10px] font-mono uppercase bg-slate-200 text-slate-700 font-extrabold tracking-wider px-2.5 py-1 rounded">
                  Iniciación
                </span>
              </div>

              {/* Price visual placeholder */}
              <div className="my-6 pb-6 border-b border-slate-100">
                <span className="font-display text-4xl font-extrabold text-slate-950">
                  Gratuito
                </span>
                <span className="text-sm text-slate-500 block mt-1">
                  Sin costos ocultos por activación
                </span>
              </div>

              {/* Benefit checks */}
              <ul className="space-y-3.5 my-6">
                {basicBenefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-slate-700 py-0.5">
                    <div className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center shrink-0 mt-0.5 border border-slate-200">
                      <Check className="w-3.5 h-3.5 text-slate-500" />
                    </div>
                    <span className="text-sm sm:text-base">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-6">
              <button
                onClick={handleScrollToForm}
                className="w-full py-3.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-800 font-bold hover:bg-slate-200 active:scale-98 transition-all cursor-pointer text-center"
              >
                Empezar gratis
              </button>
            </div>
          </div>

          {/* PLAN PLUS */}
          <div className="rounded-3xl bg-gradient-to-b from-[#00E37C]/5 via-white to-white border-2 border-[#00E37C] p-8 shadow-[0_10px_35px_rgba(0,227,124,0.06)] relative flex flex-col justify-between hover:scale-[1.01] transition-all duration-300">
            {/* Best Value Bubble */}
            <div className="absolute -top-3.5 right-6 px-3.5 py-1 rounded-full bg-[#00E37C] text-ivoo-navy text-[11px] font-bold tracking-widest uppercase flex items-center gap-1.5 shadow-md">
              <Sparkles className="w-3.5 h-3.5 text-ivoo-navy fill-ivoo-navy" /> RECOMENDADO
            </div>

            <div>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="font-display text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                    Plan Plus
                  </h3>
                  <p className="text-sm text-[#00AA5B] font-semibold mt-1">
                    Para desbloquear más beneficios.
                  </p>
                </div>
                <span className="text-[10px] font-mono uppercase bg-[#00E37C]/15 text-[#008A4B] font-extrabold tracking-wider px-2.5 py-1 rounded border border-[#00E37C]/20">
                  Preferido
                </span>
              </div>

              {/* Price visual placeholder */}
              <div className="my-6 pb-6 border-b border-slate-100">
                <span className="font-display text-4xl font-extrabold text-slate-950">
                  VIP Plus
                </span>
                <span className="text-sm text-slate-500 block mt-1">
                  Desbloqueado por buen comportamiento
                </span>
              </div>

              {/* Benefit checks */}
              <ul className="space-y-3.5 my-6">
                {plusBenefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-slate-700 py-0.5">
                    <div className="w-5 h-5 rounded-full bg-[#00E37C]/10 flex items-center justify-center shrink-0 mt-0.5 border border-[#00E37C]/20">
                      <Check className="w-3.5 h-3.5 text-[#00AA5B]" />
                    </div>
                    <span className="text-sm sm:text-base font-medium">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-6">
              <button
                onClick={handleScrollToForm}
                className="w-full py-4 rounded-xl bg-[#00E37C] text-ivoo-navy font-black hover:bg-[#00df73] active:scale-98 shadow-[0_6px_20px_rgba(0,227,124,0.2)] hover:shadow-[0_10px_25px_rgba(0,227,124,0.3)] transition-all cursor-pointer text-center text-base"
              >
                Conocer Premium
              </button>
            </div>
          </div>

        </div>

        {/* Brand Disclaimer Notice */}
        <div className="max-w-3xl mx-auto mt-16 p-4 rounded-2xl bg-slate-50 border border-slate-200 flex gap-3 text-left">
          <HelpCircle className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
          <p className="text-xs text-slate-500 leading-normal">
            Los montos, beneficios y condiciones están sujetos a evaluación, perfil del cliente, comportamiento de pago y políticas vigentes de Creditivoo.
          </p>
        </div>

      </div>
    </section>
  );
}
