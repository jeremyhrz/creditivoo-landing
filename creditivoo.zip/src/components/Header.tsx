/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Menu, X, ArrowRight } from 'lucide-react';
import Logo from './Logo';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Monitor scroll height to make standard frosted-glass sticky header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Inicio', href: '#inicio' },
    { name: 'Qué es', href: '#que-es' },
    { name: 'Cómo funciona', href: '#como-funciona' },
    { name: 'Planes', href: '#planes' },
    { name: 'Simulador', href: '#simulador' },
    { name: 'Beneficios', href: '#beneficios' },
    { name: 'Requisitos', href: '#requisitos' },
    { name: 'Preguntas', href: '#preguntas' },
  ];

  const handleScrollTo = (id: string) => {
    setIsOpen(false);
    const element = document.querySelector(id);
    if (element) {
      const offset = 80; // Header height
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md border-b border-slate-200 py-3 shadow-sm'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="cursor-pointer" onClick={() => handleScrollTo('#inicio')}>
            <Logo variant="horizontal" size="md" />
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-7">
            {menuItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleScrollTo(item.href)}
                className="text-slate-700 hover:text-[#00E37C] text-sm font-semibold cursor-pointer transition-colors"
                id={`nav-${item.href.replace('#', '')}`}
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Desktop Call To Action */}
          <div className="hidden lg:flex items-center">
            <button
              onClick={() => handleScrollTo('#solicitud')}
              className="px-5 py-2.5 rounded-full bg-[#00E37C] text-ivoo-navy font-bold text-sm tracking-wide shadow-[0_4px_15px_rgba(0,227,124,0.15)] hover:shadow-[0_6px_20px_rgba(0,227,124,0.3)] hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              id="cta-header-desktop"
            >
              Solicitar Creditivoo
              <ArrowRight className="w-4 h-4 text-ivoo-navy" />
            </button>
          </div>

          {/* Mobile Burger Button */}
          <div className="flex lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-800 hover:text-[#00E37C] p-2 focus:outline-none focus:ring-2 focus:ring-[#00E37C]/50 rounded-lg"
              aria-label="Toggle Menu"
              id="mobile-menu-btn"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <div
        className={`lg:hidden fixed inset-x-0 top-[72px] bg-white/95 backdrop-blur-lg border-b border-slate-200 transition-all duration-300 ease-in-out z-40 ${
          isOpen ? 'opacity-100 translate-y-0 scale-y-100' : 'opacity-0 -translate-y-4 scale-y-0 pointer-events-none'
        } origin-top`}
      >
        <div className="px-4 pt-4 pb-6 space-y-3 shadow-xl">
          {menuItems.map((item) => (
            <button
              key={item.name}
              onClick={() => handleScrollTo(item.href)}
              className="block w-full text-left px-4 py-3 text-slate-800 hover:bg-slate-50 hover:text-[#00E37C] text-base font-semibold rounded-xl transition-all"
            >
              {item.name}
            </button>
          ))}
          <div className="pt-4 border-t border-slate-100 px-2">
            <button
              onClick={() => handleScrollTo('#solicitud')}
              className="w-full py-3 rounded-xl bg-[#00E37C] text-ivoo-navy font-bold text-center flex items-center justify-center gap-2 shadow-[0_4px_15px_rgba(0,227,124,0.25)] hover:bg-[#00df73] active:scale-95 transition-all text-base cursor-pointer"
              id="cta-header-mobile"
            >
              Solicitar Creditivoo
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
