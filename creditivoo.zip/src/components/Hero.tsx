/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { 
  ArrowRight, 
  Calculator, 
  CheckCircle, 
  Sparkles, 
  Bell, 
  HelpCircle, 
  Eye, 
  EyeOff, 
  Coins, 
  Receipt, 
  Gem, 
  CreditCard, 
  Laptop, 
  Scan, 
  MoreHorizontal 
} from 'lucide-react';
import Logo from './Logo';

export default function Hero() {
  const [showBalance, setShowBalance] = useState(true);

  const handleScrollTo = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="inicio" className="relative min-h-screen pt-32 pb-20 flex items-center justify-center overflow-hidden bg-gradient-to-b from-slate-50 via-white to-white select-none">
      
      {/* Subtle modern background grids */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.012)_1.5px,transparent_1.5px),linear-gradient(90deg,rgba(0,0,0,0.012)_1.5px,transparent_1.5px)] bg-[size:32px_32px] pointer-events-none opacity-80" />
      
      {/* Decorative radial gradients to add a soft green flare */}
      <div className="absolute top-1/4 -left-1/4 w-[500px] h-[500px] rounded-full bg-[#00E37C]/5 blur-[120px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 -right-1/4 w-[500px] h-[500px] rounded-full bg-indigo-500/3 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full font-sans">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Hero Left Column Text & Messaging */}
          <div className="lg:col-span-6 flex flex-col space-y-8 text-left">
            <div>
              <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#00E37C]/10 border border-[#00E37C]/20 text-[#00AA5B] text-xs font-semibold tracking-wide uppercase mb-5">
                <Sparkles className="w-3.5 h-3.5 text-[#00AA5B] fill-[#00AA5B]" /> El financiamiento exclusivo de IVOO
              </span>
              
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-black tracking-tight text-slate-900 leading-[1.05]">
                <span className="block text-slate-950">
                  Creditivoo
                </span>
                <span className="block text-[#00AA5B] drop-shadow-sm mt-2">
                  Llévatelo hoy, págalo a tu ritmo.
                </span>
              </h1>
            </div>

            <p className="text-slate-600 text-lg sm:text-xl font-normal leading-relaxed max-w-xl">
              Compra tecnología, electrodomésticos y productos seleccionados en las tiendas IVOO de todo el país con planes flexibles, cuotas predecibles y beneficios acumulables de inmediato.
            </p>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 shadow-sm max-w-lg">
              <span className="text-lg md:text-xl font-medium text-[#008A4B] italic">
                “Ya no hace falta tener todo pa’ tenerlo todo 😉”
              </span>
            </div>

            {/* Direct non-bank labels to build trust */}
            <div className="flex flex-wrap gap-x-6 gap-y-2.5 text-slate-600 text-sm font-semibold">
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-[#00E37C]" /> Sin bancos tradicionales
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-[#00E37C]" /> Sin vueltas
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-[#00E37C]" /> Sin letra chiquita
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                onClick={() => handleScrollTo('#solicitud')}
                className="px-8 py-4 rounded-xl bg-[#00E37C] hover:bg-[#00df73] text-ivoo-navy font-bold text-base tracking-wide shadow-[0_8px_25px_rgba(0,227,124,0.2)] hover:shadow-[0_12px_30px_rgba(0,227,124,0.3)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2.5 cursor-pointer"
                id="hero-primary-cta"
              >
                Solicitar Creditivoo
                <ArrowRight className="w-5 h-5 text-ivoo-navy" />
              </button>
              
              <button
                onClick={() => handleScrollTo('#simulador')}
                className="px-8 py-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-base tracking-wide border border-slate-200 hover:border-slate-300 transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-sm"
                id="hero-secondary-cta"
              >
                <Calculator className="w-5 h-5 text-[#00AA5B]" />
                Simular mi compra
              </button>
            </div>
          </div>

          {/* Hero Right Column: High Fidelity replica representation of Creditivoo app home */}
          <div className="lg:col-span-6 relative flex justify-center lg:justify-end">
            
            {/* Visual background glow underneath card to give physical depth */}
            <div className="absolute w-80 h-80 rounded-full bg-[#00E37C]/10 blur-[80px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none" />

            {/* Smartphone Physical Bezel Frame */}
            <div className="w-full max-w-[370px] bg-slate-900 p-2.5 pb-3.5 rounded-[46px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.15)] border-4 border-slate-800/95 relative overflow-hidden select-none">
              
              {/* Dynamic Camera island notch */}
              <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-4.5 bg-slate-900 rounded-full z-30 flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-800/40 border border-slate-700/50 mr-4" />
                <div className="w-1.5 h-1.5 rounded-full bg-blue-900/40" />
              </div>

              {/* Screen Content Window */}
              <div className="w-full bg-slate-50 rounded-[36px] overflow-hidden flex flex-col relative z-20 min-h-[610px] shadow-inner text-slate-800 font-sans text-xs">
                
                {/* 1. Header Segment with Neon Green background */}
                <div className="bg-[#00E37C] text-slate-950 px-4 pt-3 pb-7 rounded-b-[24px] relative overflow-hidden flex flex-col justify-between">
                  
                  {/* Status Bar Indicators */}
                  <div className="flex justify-between items-center text-[10px] font-extrabold tracking-tight px-1 z-10 text-slate-900/80">
                    <span>9:41</span>
                    <div className="flex items-center gap-1">
                      <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L4.35 19.4a1 1 0 001.41 1.41l1.79-1.78C9.07 19.7 10.5 20 12 20c4.97 0 9-4.03 9-9s-4.03-9-9-9zm0 15c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/>
                      </svg>
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zM4 6h16v12H4V6z"/>
                      </svg>
                    </div>
                  </div>

                  {/* Greeting avatar and names row */}
                  <div className="flex justify-between items-center mt-4 px-1 z-10">
                    
                    {/* User profile details */}
                    <div className="flex items-center gap-2.5">
                      
                      {/* CSS-Art Crowned "Ivitoo" Avatar exactly matching image */}
                      <div className="relative w-11 h-11 rounded-full bg-white/10 flex items-center justify-center border border-white/20 shadow-sm shrink-0">
                        {/* Golden Crown */}
                        <span className="absolute -top-1 -left-1.5 text-xs select-none rotate-[-12deg] z-15 filter drop-shadow">👑</span>
                        
                        {/* Smiling bearded guy with glasses profile container */}
                        <div className="w-9 h-9 rounded-full bg-amber-100 relative flex flex-col justify-end items-center overflow-hidden border border-amber-200 shadow-inner mt-2">
                          {/* Sunglasses black shade */}
                          <div className="absolute top-1.5 w-6 h-2 bg-slate-950 rounded flex gap-1 z-20 px-0.5">
                            <div className="w-2.5 h-1.5 bg-slate-900 rounded-full" />
                            <div className="w-2.5 h-1.5 bg-slate-900 rounded-full" />
                          </div>
                          {/* Cheek details */}
                          <div className="absolute top-3 w-5 h-2 bg-rose-200/40 rounded-full z-10" />
                          {/* Signature Beard of Ivitoo */}
                          <div className="w-full h-4 bg-slate-950 border-t-2 border-slate-900 rounded-b-xl flex justify-center items-center">
                            <div className="w-2.5 h-1 bg-[#00E37C] rounded-full mt-1" />
                          </div>
                        </div>
                      </div>

                      {/* Info lines text */}
                      <div className="flex flex-col text-left">
                        {/* PLUS Badge */}
                        <span className="inline-block w-fit px-1.5 py-0.5 rounded-[4px] text-[8px] font-mono leading-none bg-white text-[#00AA5B] font-extrabold uppercase mb-0.5 shadow-sm">
                          PLUS
                        </span>
                        <h3 className="font-extrabold text-sm text-slate-950 tracking-tight leading-tighter">
                          Hola, Ivitoo
                        </h3>
                      </div>
                    </div>

                    {/* Support & Notification row */}
                    <div className="flex items-center gap-1 text-slate-950">
                      <button className="p-1.5 hover:bg-white/10 active:scale-95 transition-all rounded-full relative">
                        <Bell className="w-4 h-4" />
                        <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-rose-500 rounded-full" />
                      </button>
                      <button className="p-1.5 hover:bg-white/10 active:scale-95 transition-all rounded-full">
                        <HelpCircle className="w-4 h-4" />
                      </button>
                    </div>

                  </div>

                </div>

                {/* 2. Floating Original Balance Card (White card, floating overlaps top green) */}
                <div className="bg-white mx-4 -mt-5 p-4 rounded-2xl shadow-[0_8px_25px_rgba(0,0,0,0.06)] border border-slate-100 relative z-20 flex flex-col justify-between">
                  
                  {/* Card Header row */}
                  <div className="flex justify-between items-center mb-3.5 font-sans">
                    <div className="flex items-center gap-1.5">
                      {/* Logo mockup inside white box */}
                      <Logo variant="icon" size="sm" className="scale-75" />
                      <span className="text-[11px] font-mono font-black tracking-[0.1em] text-slate-900">
                        CREDITIVOO
                      </span>
                    </div>

                    {/* Privacy toggle option */}
                    <button 
                      onClick={() => setShowBalance(!showBalance)}
                      className="text-slate-400 hover:text-slate-600 p-1 rounded-md active:scale-95 transition-all"
                    >
                      {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Account detail split */}
                  <div className="grid grid-cols-2 gap-2 border-t border-slate-100 pt-3 relative font-sans">
                    <div className="absolute top-3 bottom-0 left-1/2 w-px bg-slate-100" />
                    
                    {/* Available limit */}
                    <div className="text-left">
                      <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">
                        Disponible:
                      </span>
                      <span className="text-base sm:text-lg font-black text-[#00AA5B] font-mono mt-0.5 block">
                        {showBalance ? 'USD $500' : 'USD ••••'}
                      </span>
                    </div>
                    
                    {/* Payable amount */}
                    <div className="text-left pl-3">
                      <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">
                        Por Pagar:
                      </span>
                      <span className="text-base sm:text-lg font-black text-slate-800 font-mono mt-0.5 block">
                        {showBalance ? 'USD $300' : 'USD ••••'}
                      </span>
                    </div>
                  </div>

                </div>

                {/* 3. Promo Banner split grid box */}
                <div className="mx-4 mt-3 grid grid-cols-12 rounded-xl overflow-hidden border border-[#00E37C]/20 shadow-sm font-sans shrink-0 bg-white">
                  
                  {/* Left green tag split */}
                  <div className="col-span-8 bg-[#00E37C] p-2.5 flex flex-col justify-center text-left leading-normal">
                    <span className="text-[9px] font-black text-slate-950 uppercase leading-none tracking-tight block">
                      Compra hoy desde
                    </span>
                    <span className="text-xs font-black text-slate-950 tracking-tight leading-tighter block uppercase">
                      0% de inicial
                    </span>
                  </div>

                  {/* Right white gem details split */}
                  <div className="col-span-4 bg-white p-2 flex flex-col justify-center items-center text-center">
                    <span className="text-[8px] text-slate-500 font-bold font-mono tracking-wider block">
                      GEMAS:
                    </span>
                    <div className="flex items-center gap-1 font-mono font-black text-sm text-slate-800 tracking-tight mt-0.5">
                      <span>240</span>
                      <div className="w-3.5 h-3.5 bg-[#00E37C] rounded rotate-45 flex items-center justify-center shrink-0">
                        <div className="w-1.5 h-1.5 bg-white rounded-full -rotate-45" />
                      </div>
                      <span className="text-[9px] text-slate-400 font-bold font-sans">+</span>
                    </div>
                  </div>

                </div>

                {/* 4. Quick Action Buttons circular list */}
                <div className="mx-4 mt-4 grid grid-cols-4 gap-2 text-center font-sans">
                  
                  {/* Action 1 */}
                  <div className="flex flex-col items-center">
                    <button className="w-11 h-11 rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-[#00AA5B] shadow-sm hover:scale-105 active:scale-95 transition-all">
                      <Coins className="w-5 h-5" />
                    </button>
                    <span className="text-[9px] font-bold text-slate-600 mt-1.5 block leading-tight">
                      Mis Cuotas
                    </span>
                  </div>

                  {/* Action 2 */}
                  <div className="flex flex-col items-center">
                    <button className="w-11 h-11 rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-[#00AA5B] shadow-sm hover:scale-105 active:scale-95 transition-all">
                      <Receipt className="w-5 h-5" />
                    </button>
                    <span className="text-[9px] font-bold text-slate-600 mt-1.5 block leading-tight">
                      Mis Movimientos
                    </span>
                  </div>

                  {/* Action 3 */}
                  <div className="flex flex-col items-center">
                    <button className="w-11 h-11 rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-emerald-500 shadow-sm hover:scale-105 active:scale-95 transition-all">
                      <Gem className="w-5 h-5" />
                    </button>
                    <span className="text-[9px] font-bold text-slate-600 mt-1.5 block leading-tight">
                      Mis Gemas
                    </span>
                  </div>

                  {/* Action 4 */}
                  <div className="flex flex-col items-center">
                    <button className="w-11 h-11 rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-[#00AA5B] shadow-sm hover:scale-105 active:scale-95 transition-all">
                      <CreditCard className="w-5 h-5" />
                    </button>
                    <span className="text-[9px] font-bold text-slate-600 mt-1.5 block leading-tight">
                      Mis Compras
                    </span>
                  </div>

                </div>

                {/* 5. Novedades Wide Group Segment Banner */}
                <div className="mx-4 mt-4 text-left font-sans flex flex-col shrink-0">
                  <span className="text-[10px] font-black tracking-widest text-slate-800 uppercase mb-2 block font-mono pl-0.5">
                    Novedades
                  </span>

                  {/* Dotted stylish center border box as home banner */}
                  <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col justify-center items-center min-h-[90px] relative overflow-hidden shadow-sm">
                    <div className="absolute inset-0 bg-gradient-to-tr from-cyan-50/20 via-white to-emerald-50/10 opacity-70 pointer-events-none" />
                    
                    {/* The centered box layout border */}
                    <div className="relative border-2 border-slate-800 p-2.5 px-4 rounded-md bg-white shadow-xs text-center w-full">
                      <h4 className="text-slate-900 text-[10px] font-extrabold tracking-tight leading-none uppercase">
                        ¿Qué hay en IVOO
                      </h4>
                      <h4 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-[#00AA5B] via-[#00E37C] to-emerald-600 tracking-tight leading-none mt-0.5 uppercase">
                        ESTA SEMANA?
                      </h4>
                      {/* Fake pointer arrow inside card */}
                      <span className="absolute -bottom-1 -right-1 text-base pointer-events-none drop-shadow">☝️</span>
                    </div>

                  </div>
                </div>

                {/* 6. Descuentos and Ayuda Bento split columns */}
                <div className="mx-4 mt-3 grid grid-cols-2 gap-3 mb-4 font-sans text-left items-stretch">
                  
                  {/* Left Column: Descuentos Laptop card block */}
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black tracking-widest text-slate-800 uppercase mb-1.5 block font-mono pl-0.5">
                      Descuentos
                    </span>
                    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs flex flex-col justify-between flex-1">
                      {/* Picture mock with percent badge top-left */}
                      <div className="relative bg-gradient-to-b from-slate-50 to-slate-100 h-16 flex items-center justify-center p-2">
                        <span className="absolute top-1 left-1 bg-rose-500 text-white font-mono text-[8px] font-black px-1.5 py-0.5 rounded leading-none text-center">
                          17.78%
                        </span>
                        <Laptop className="w-8 h-8 text-slate-400" />
                      </div>
                      {/* Footer bar values */}
                      <div className="p-1.5 border-t border-slate-100 bg-slate-50 flex flex-col">
                        <span className="text-[8px] text-slate-500 font-bold truncate leading-none">
                          Laptop Siragon NB-20...
                        </span>
                        <span className="text-[9px] text-slate-800 font-black mt-1 font-mono leading-none">
                          $369.99
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Ivitoo Assistant Speech Advice bubble box */}
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black tracking-widest text-slate-800 uppercase mb-1.5 block font-mono pl-0.5">
                      Ayuda
                    </span>
                    <div className="bg-slate-100/50 border border-slate-200 rounded-xl p-2 flex flex-col justify-between items-center text-center flex-1">
                      <span className="text-[8px] text-slate-500 font-bold uppercase block leading-none tracking-tight mb-2">
                        Necesitas ayuda, habla con Ivitoo:
                      </span>
                      {/* Chat text pointer bubble indicator */}
                      <div className="bg-white border border-slate-100 p-2 rounded-lg rounded-tr-none text-[8.5px] text-slate-700 font-bold leading-normal text-left shadow-xs mb-2 relative max-w-[95%]">
                        Hola! Soy Ivitoo, tu asesor virtual de Creditivoo.
                      </div>
                      
                      {/* CSS cartoon mini-avatar of chatbot at bottom */}
                      <div className="w-8 h-8 rounded-full bg-[#00E37C]/25 border border-[#00E37C]/40 flex items-center justify-center overflow-hidden shrink-0 mt-auto relative">
                        <div className="w-6 h-6 rounded-full bg-amber-100 relative flex flex-col justify-end items-center overflow-hidden border border-amber-200 mt-1 shadow-inner">
                          {/* shades */}
                          <div className="absolute top-1 w-4 h-1 bg-slate-950 rounded z-10" />
                          {/* beard */}
                          <div className="w-full h-2 bg-slate-950 border-t border-slate-800 rounded-b-xl" />
                        </div>
                      </div>

                    </div>
                  </div>

                </div>

                {/* 7. Bottom navigation pill sticky bar of mobile phone */}
                <div className="bg-slate-50 border-t border-slate-200/80 p-2.5 px-5 flex justify-between items-center rounded-b-[36px] mt-auto z-20">
                  {/* Homepill banner inside bar */}
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#00E37C] text-ivoo-navy text-[10px] font-black rounded-xl shadow-xs cursor-pointer">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                    </svg>
                    <span>Home</span>
                  </div>

                  {/* Scan overlay code button */}
                  <button className="text-slate-400 hover:text-[#00E37C] active:scale-95 transition-all p-1">
                    <Scan className="w-5 h-5 stroke-[2]" />
                  </button>

                  {/* Options row dot menu */}
                  <button className="text-slate-400 hover:text-[#00E37C] active:scale-95 transition-all p-1">
                    <MoreHorizontal className="w-5 h-5 stroke-[2]" />
                  </button>
                </div>

              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
