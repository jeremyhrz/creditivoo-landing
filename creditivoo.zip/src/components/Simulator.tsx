/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, HelpCircle, DollarSign, Calculator, Info } from 'lucide-react';

interface SimulatorProps {
  onSimulateSelect: (price: number, plan: 'basic' | 'plus', productName: string) => void;
}

export default function Simulator({ onSimulateSelect }: SimulatorProps) {
  // Preset select triggers
  const PRESETS = [
    { name: 'Smart TV Síragon 50"', price: 349, category: 'Televisor' },
    { name: 'Xiaomi Redmi Note 13', price: 189, category: 'Teléfono' },
    { name: 'Aire Split 12000 BTU', price: 299, category: 'Electrodoméstico' },
    { name: 'Laptop ASUS VivoBook', price: 549, category: 'Computación' },
    { name: 'Nevera Condesa 10' , price: 429, category: 'Línea Blanca' },
  ];

  const [selectedPreset, setSelectedPreset] = useState<number>(-1);
  const [productPrice, setProductPrice] = useState<number>(349);
  const [productName, setProductName] = useState<string>('Smart TV Síragon 50"');
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'plus'>('plus');
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(20); // 20% standard
  const [installments, setInstallments] = useState<number>(3); // 3, 4, or 6 terms

  // Enforce validation based on plans
  useEffect(() => {
    if (selectedPlan === 'basic') {
      // Basic requires minimum 30% initial
      if (downPaymentPercent < 30) {
        setDownPaymentPercent(30);
      }
      // Basic only allows 3 installments
      setInstallments(3);
    }
  }, [selectedPlan]);

  const handlePresetClick = (idx: number) => {
    setSelectedPreset(idx);
    const preset = PRESETS[idx];
    setProductPrice(preset.price);
    setProductName(preset.name);
    
    // Auto adjust sliders to fit
    if (selectedPlan === 'basic') {
      setDownPaymentPercent(30);
      setInstallments(3);
    } else {
      setDownPaymentPercent(20);
      setInstallments(4);
    }
  };

  const handlePriceChange = (val: number) => {
    setProductPrice(val);
    setSelectedPreset(-1); // Remove active preset choice
    setProductName('Producto Personalizado');
  };

  const handlePlanChange = (plan: 'basic' | 'plus') => {
    setSelectedPlan(plan);
    if (plan === 'basic') {
      setDownPaymentPercent(30);
      setInstallments(3);
    } else {
      setDownPaymentPercent(20);
      setInstallments(3);
    }
  };

  // Math equations
  const calculatedInitial = Math.round((productPrice * downPaymentPercent) / 100);
  const calculatedFinanced = productPrice - calculatedInitial;
  
  // Basic is strictly interest-free pure splits, Plus might have a tiny administrative facility fee
  const administrativeFactor = selectedPlan === 'plus' ? 1.05 : 1.0; // 5% flat administrative facilment
  const estimatedCuota = Math.round((calculatedFinanced * administrativeFactor) / installments);

  const handleApplySimulator = () => {
    onSimulateSelect(productPrice, selectedPlan, productName);
    
    // Smooth scroll to form
    const element = document.querySelector('#solicitud');
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="simulador" className="py-24 bg-slate-50 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 right-0 w-96 h-96 rounded-full bg-emerald-500/5 blur-[120px]" />
      <div className="absolute bottom-1/4 left-0 w-96 h-96 rounded-full bg-blue-500/5 blur-[120px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 font-sans">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono font-extrabold tracking-[0.25em] text-[#00E37C] uppercase bg-[#00E37C]/5 px-3.5 py-1.5 rounded-full border border-[#00E37C]/15">
            CALCULADORA DE FLEXIBILIDAD
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black text-slate-900 tracking-tight mt-5">
            Simulador de Compra
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-[#00E37C] to-[#00FF88] mx-auto my-6 rounded-full" />
          <p className="text-slate-600 text-lg">
            Calcula instantáneamente tus cuotas agregando el precio aproximado del equipo de tu interés.
          </p>
        </div>

        {/* Outer Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-6xl mx-auto">
          
          {/* Presets and Inputs (Column 7/12) */}
          <div className="lg:col-span-7 bg-white border border-slate-200/85 p-6 sm:p-8 rounded-3xl flex flex-col justify-between shadow-sm">
            <div>
              {/* Presets Title */}
              <span className="text-xs font-mono tracking-widest text-[#00E37C] font-semibold uppercase block mb-3">
                1. Elige un producto de referencia
              </span>
              <div className="flex flex-wrap gap-2.5 mb-8">
                {PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handlePresetClick(idx)}
                    className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all cursor-pointer ${
                      selectedPreset === idx
                        ? 'bg-[#00E37C]/15 border-[#00E37C] text-slate-900 font-bold'
                        : 'bg-slate-100 border-slate-200 text-slate-750 hover:bg-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {preset.name} (${preset.price})
                  </button>
                ))}
              </div>

              {/* Slider 1: Product Price */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2.5">
                  <label htmlFor="price-slider" className="text-sm font-bold text-slate-800">
                    Precio del producto
                  </label>
                  <div className="flex items-center gap-1.5 font-mono text-lg font-bold text-slate-900">
                    <span className="text-slate-400 font-semibold">$</span>
                    <span>{productPrice}</span>
                  </div>
                </div>
                <input
                  id="price-slider"
                  type="range"
                  min="50"
                  max="2000"
                  step="25"
                  value={productPrice}
                  onChange={(e) => handlePriceChange(Number(e.target.value))}
                  className="w-full h-2 rounded-lg bg-slate-200 appearance-none cursor-pointer accent-[#00E37C]"
                />
                <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-2">
                  <span>Min: $50</span>
                  <span>Max: $2,000</span>
                </div>
              </div>

              {/* Option Selector: Plan Select */}
              <div className="grid grid-cols-2 gap-4 mb-6 pt-4 border-t border-slate-100">
                <div>
                  <label className="text-xs font-mono font-semibold text-slate-400 tracking-wider uppercase block mb-2">
                    2. Selecciona tu plan
                  </label>
                  <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
                    <button
                      onClick={() => handlePlanChange('basic')}
                      className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                        selectedPlan === 'basic'
                          ? 'bg-white text-slate-800 shadow-sm border border-slate-200'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      Básico
                    </button>
                    <button
                      onClick={() => handlePlanChange('plus')}
                      className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                        selectedPlan === 'plus'
                          ? 'bg-[#00E37C] text-ivoo-navy shadow-sm'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      Plus VIP
                    </button>
                  </div>
                </div>

                {/* Term install Selector */}
                <div>
                  <label className="text-xs font-mono font-semibold text-slate-400 tracking-wider uppercase block mb-2">
                    3. Número de pagos
                  </label>
                  {selectedPlan === 'basic' ? (
                    <div className="px-4 py-2 font-mono text-sm text-slate-600 border border-slate-200 rounded-xl bg-slate-50 font-semibold text-center">
                      3 cuotas fijas
                    </div>
                  ) : (
                    <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
                      {[3, 4, 6].map((term) => (
                        <button
                          key={term}
                          onClick={() => setInstallments(term)}
                          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                            installments === term
                              ? 'bg-white text-slate-800 shadow-sm border border-slate-200'
                              : 'text-slate-500 hover:text-slate-800'
                          }`}
                        >
                          {term}c
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Slider 2: Down Payment Percent */}
              <div>
                <div className="flex justify-between items-center mb-2.5">
                  <label htmlFor="downpayment-slider" className="text-sm font-bold text-slate-800">
                    Inicial estimada
                  </label>
                  <span className="font-mono text-sm font-bold text-[#008A4B] bg-[#00E37C]/10 px-2 py-0.5 rounded border border-[#00E37C]/25">
                    {downPaymentPercent}% (${calculatedInitial})
                  </span>
                </div>
                <input
                  id="downpayment-slider"
                  type="range"
                  min={selectedPlan === 'basic' ? 30 : 0}
                  max="80"
                  step="5"
                  value={downPaymentPercent}
                  onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                  className="w-full h-2 rounded-lg bg-slate-200 appearance-none cursor-pointer accent-[#00E37C]"
                />
                <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-2">
                  <span>{selectedPlan === 'basic' ? 'Básico Min: 30%' : 'Mínimo: 0%'}</span>
                  <span>Máximo: 80%</span>
                </div>
              </div>

            </div>

            <div className="pt-6 mt-6 border-t border-slate-150">
              <span className="text-lg md:text-xl font-medium text-slate-700 italic">
                “Saca la cuenta y date cuenta.” 💰
              </span>
            </div>
          </div>

          {/* Calculator Output invoice representation (Column 5/12) */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#00E37C]/5 via-white to-white border-2 border-[#00E37C] p-6 sm:p-8 rounded-3xl flex flex-col justify-between shadow-lg relative">
            
            {/* Holographic lines */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#00E37C]/5 rounded-full blur-2xl pointer-events-none" />

            {/* Title / invoice header */}
            <div>
              <div className="flex items-center gap-2 mb-6 pb-4 border-b border-slate-250">
                <Calculator className="w-5 h-5 text-slate-800" />
                <span className="text-xs font-mono font-extrabold tracking-widest text-[#008A4B] uppercase">
                  SIMULACIÓN ESTIMADA
                </span>
              </div>

              {/* Selected Preset indicator */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl mb-6">
                <span className="text-[10px] font-mono text-slate-400 block uppercase tracking-wide">
                  Equipo Simulado
                </span>
                <span className="text-sm font-semibold text-slate-900 mt-0.5 block truncate">
                  {productName}
                </span>
                <span className="text-xs text-slate-500 block font-mono mt-0.5">
                  Precio Total: ${productPrice} USD
                </span>
              </div>

              {/* Rows */}
              <div className="space-y-4">
                <div className="flex justify-between items-center text-sm py-0.5">
                  <span className="text-slate-600">Planiﬁcación Inicial ({downPaymentPercent}%)</span>
                  <span className="font-mono font-semibold text-slate-800">${calculatedInitial} USD</span>
                </div>
                
                <div className="flex justify-between items-center text-sm py-0.5">
                  <span className="text-slate-600">Monto Financiado</span>
                  <span className="font-mono font-semibold text-slate-800">${calculatedFinanced} USD</span>
                </div>

                <div className="flex justify-between items-center text-sm py-0.5">
                  <span className="text-slate-600">Plan de Interés</span>
                  <span className="text-xs font-semibold px-2 py-0.5 bg-[#00E37C]/15 text-[#008A4B] border border-[#00E37C]/25 rounded uppercase">
                    {selectedPlan === 'basic' ? 'Basic' : 'Plus VIP'}
                  </span>
                </div>

                <div className="pt-4 border-t border-slate-200">
                  <span className="text-xs font-mono text-slate-500 block uppercase tracking-wide">
                    Cuotas Estimadas ({installments} pagos)
                  </span>
                  <div className="flex items-end gap-1 mt-1.5">
                    <span className="text-4xl font-display font-black text-[#00AA5B] tracking-tight">
                      ${estimatedCuota}
                    </span>
                    <span className="text-sm text-slate-700 font-semibold mb-1">
                      USD / Cuota
                    </span>
                  </div>
                  
                  {/* Informative message */}
                  <div className="flex items-center gap-1.5 mt-3 text-[11px] text-slate-600">
                    <Info className="w-3.5 h-3.5 text-slate-800" />
                    <span>Esta simulación es referencial.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Evaluation Direct request button CTA */}
            <div className="pt-6 mt-6 border-t border-slate-200">
              <button
                onClick={handleApplySimulator}
                className="w-full py-4 rounded-xl bg-[#00E37C] text-ivoo-navy font-black hover:bg-[#00df73] active:scale-98 shadow-[0_5px_15px_rgba(0,227,124,0.15)] hover:shadow-[0_8px_25px_rgba(0,227,124,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer text-base"
                id="simulator-action-btn"
              >
                Solicitar evaluación
                <ArrowRight className="w-5 h-5" />
              </button>

              <span className="block text-[10px] text-slate-500 font-medium text-center mt-3">
                La aprobación final y las condiciones reales dependen de la evaluación Creditivoo.
              </span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
